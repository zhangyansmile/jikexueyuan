$(document).ready(function(){
	refresh('推荐');
	$('nav a').click(function(e){
		e.preventDefault();
		var type = $(this).text();
		refresh(type);
	});
})

function refresh(type){
	var $lists=$('article ul');
	$lists.empty();  //先清除掉所有的新闻列表；

	$.ajax({
		type:'get',
		url:"../baidunews/server/getnews.php",
		datatype:'json',
//		data:{"newstype":type},
		success:function(data){
			data.forEach(function(item,index,array){ 				
				var $list = $('<li></li>').prependTo($lists);
				var $newsImg = $('<div></div>').addClass('news-img').appendTo($list);
				console.log(item);
				var $img = $('<img>').attr('src',item.newsimg).appendTo($newsImg);
				var $newscontent = $('<div></div>').addClass('news-content').appendTo($list);
				var $h1 = $('<h1></h1>').html(item.newstitle).appendTo($newscontent);
				var $p = $('<p></p>').appendTo($newscontent);
				var $newstime = $('<span></span>').html(item.newstime).appendTo($p);
				var $newssrc = $('<span></span>').html(item.newssrc).appendTo($p);
			})
			
		}
	});
	
}



//回到顶部
$(window).scroll(function(){
   var sc=$(window).scrollTop();
   if(sc>0){
    $(".gototop span").css("display","block");
   }else{
   $(".gototop span").css("display","none");
   }
 })
 $(".gototop").click(function(){
   var sc=$(window).scrollTop();
   $('body,html').animate({scrollTop:0},100);
 })
