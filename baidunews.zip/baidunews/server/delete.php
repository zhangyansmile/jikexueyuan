<?php
	header("Content-type:application/json; charset=utf-8");
	require_once('db.php');
	
	if($link){
		$newsid = $_POST['newsid'];
		mysqli_query($link, "SET NAMES utf8"); //  设置不能乱码
		
		$sql = "DELETE FROM `news` WHERE `news`.`id` = {$newsid}";
		
		mysqli_query($link, $sql);
		
		echo json_encode(array('删除状态'=>'成功'));//删除成功之后需要返回一个状态，对应ajax中success内容
	}
	
	mysqli_close($link);//关闭数据库，需要传一个参数才行
	
	
	
?>