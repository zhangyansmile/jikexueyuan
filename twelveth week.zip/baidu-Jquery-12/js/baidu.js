
//header标题显示隐藏

//使用单例模式
var index = {
	init:function(argument){
		var me = this;
		me.render();
		me.bind();
	},
	render:function(){  //定义按钮
		var me = this;
		me.btn = $(".username");
	},
	bind:function(){
		var me = this;
		me.btn.mouseover(  //定义按钮事件
			function() {
				$("#user").show();
			}).mouseout(function() {
				$("#user").hide();
			});
	}
};
index.init();

//未使用单例模式
//$(function(){
//	$(".username").mouseover(
//		function(){
//			$("#user").show();
//		}
//	).mouseout(function(){
//		$("#user").hide();
//	});
//})

//天气预报的隐藏和显示
//使用单例模式
var index1 = {
	init:function(argument){
		var me = this;
		me.render();
		me.bind();
	},
	render:function(){  //定义按钮
		var me = this;
		me.btn = $(".weather-show");
	},
	bind:function(){
		var me = this;
		me.btn.mouseover(  //定义按钮事件
				function(){
					$("#weather-list").show();
				}
			).mouseout(function(){
				$("#weather-list").hide();
			});
	}
};
index1.init();

//$(function(){
//	$(".weather-show").mouseover(
//		function(){
//			$("#weather-list").show();
//		}
//	).mouseout(function(){
//		$("#weather-list").hide();
//	});
//})


//content1 标题切换
//使用单例模式
var index2 = {
	init:function(argument){
		var me = this;
		me.render();
		me.bind();
	},
	render:function(){  //定义按钮
		var me = this;
		me.btn = $("#ulitem li");
	},
	bind:function(){
		var me = this;
		me.btn.click(function() {    //定义按钮事件
		$("#ulitem li").each(function() {
			$(this).removeClass("active");
		})
		$("#content1 .l").each(function() {
			$(this).css("display", "none");
		})
		$(this).addClass("active");
		var index = $(this).index(); 
		
		switch (index) {
			case 0:
				$("#myView").css("display", "block");
				break;
			case 1:
				$("#news").css("display", "inline-block");
				break;
			case 2:
				$("#navigate").css("display", "block");
				break;
			case 3:
				$("#video").css("display", "block");
				break;
		}
	});
	}
};
index2.init();


//$(function() {
//	$("#ulitem li").click(function() {
//		$("#ulitem li").each(function() {
//			$(this).removeClass("active");
//		})
//		$("#content1 .l").each(function() {
//			$(this).css("display", "none");
//		})
//		$(this).addClass("active");
//		var index = $(this).index(); 
//		
//		switch (index) {
//			case 0:
//				$("#myView").css("display", "block");
//				break;
//			case 1:
//				$("#news").css("display", "inline-block");
//				break;
//			case 2:
//				$("#navigate").css("display", "block");
//				break;
//			case 3:
//				$("#video").css("display", "block");
//				break;
//		}
//	})
//});


//换肤
function showImgBox() {
    $("#dimgBox").slideDown();
}
function hideImgBox() {
	$("#dimgBox").slideUp();
}
$(function(){
	   
	//1.找到imgtiem下面的img标签，执行单击事件
	$(".imgitem img").click(function () {         //2.关键是要获取到当前图片的src的值,设为变量保存起来        
		var src = $(this).attr("src");         //3.把它作为网页的背景样式         
		$("body").css("background-image","url('"+src+"')");         //4.保存状态        
//		$.cookie("bg-pic", src, {expires:1});
	});
//	//5.页面打开之后判断它是否存在
//	if ($.cookie("bg-pic") == "" || $.cookie("bg-pic")==null)     {        //6.不存在就把第一张设为默认背景         
//		$("body").css("background-image", "url(img/bg0.jpg)");
//	}    
//	else{         //6.如果存在就把$.cookie("bg-pic")传进去,上一次保存的值给它
//	$("body").css("background-image", "url('" + $.cookie("bg-pic") + "')");         
//};
	
 });
//回到顶部


$(window).scroll(function(){
   var sc=$(window).scrollTop();
   if(sc>0){
    $("#goTopBtn").css("visibility","visible");
   }else{
   $("#goTopBtn").css("visibility","hidden");
   }
 })
 $("#goTopBtn").click(function(){
   var sc=$(window).scrollTop();
   $('body,html').animate({scrollTop:0},100);
 })
























