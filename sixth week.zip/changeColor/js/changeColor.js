
function red() {
	var skin=document.getElementsByTagName('article')[0];
	skin.id="skin-red";			
}
function green() {
	var skin=document.getElementsByTagName('article')[0];
	skin.id="skin-green";			
}
function blue() {
	var skin=document.getElementsByTagName('article')[0];
	skin.id="skin-blue";			
}
function orange() {
	var skin=document.getElementsByTagName('article')[0];
	skin.id="skin-orange";			
}
function orchid() {
	var skin=document.getElementsByTagName('article')[0];
	skin.id="skin-orchid";			
}

localData = {
        hname:location.hostname?location.hostname:'localStatus',
        isLocalStorage:window.localStorage?true:false,
        dataDom:null,

        initDom:function(){ //初始化
            if(!this.dataDom){
                try{
                    this.dataDom = document.getElementsByTagName('article')[0];                   
                    var exDate = new Date();
                    exDate = exDate.getDate()+30;
                    this.dataDom.expires = exDate.toUTCString();//设定过期时间
                }catch(ex){
                    return false;
                }
            }
            return true;
        },
        set:function(key,value){
            if(this.isLocalStorage){
                window.localStorage.setItem(key,value);
            }else{
                if(this.initDom()){
                    this.dataDom.load(this.hname);
                    this.dataDom.setAttribute(key,value);
                    this.dataDom.save(this.hname)
                }
            }
        },
        get:function(key){
            if(this.isLocalStorage){
                return window.localStorage.getItem(key);
            }else{
                if(this.initDom()){
                    this.dataDom.load(this.hname);
                    return this.dataDom.getAttribute(key);
                }
            }
		}
    }