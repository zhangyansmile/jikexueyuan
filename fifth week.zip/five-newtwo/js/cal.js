	 /** 
	 * 加法运算，避免数据相加小数点后产生多位数和计算精度损失。 
	 * 
	 * @param num1加数1 | num2加数2 
	 */
	function numAdd(num1, num2) {
		var baseNum, baseNum1, baseNum2;
		try {
			baseNum1 = num1.toString().split(".")[1].length;
		} catch (e) {
			baseNum1 = 0;
		}
		try {
			baseNum2 = num2.toString().split(".")[1].length;
		} catch (e) {
			baseNum2 = 0;
		}
		baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
		return (num1 * baseNum + num2 * baseNum) / baseNum;
	};
	/** 
	 * @param num1被减数 | num2减数 
	 */
	function numSub(num1, num2) {
		var baseNum, baseNum1, baseNum2;
		var precision; // 精度 
		try {
			baseNum1 = num1.toString().split(".")[1].length;
		} catch (e) {
			baseNum1 = 0;
		}
		try {
			baseNum2 = num2.toString().split(".")[1].length;
		} catch (e) {
			baseNum2 = 0;
		}
		baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
		precision = (baseNum1 >= baseNum2) ? baseNum1 : baseNum2;
		return ((num1 * baseNum - num2 * baseNum) / baseNum).toFixed(precision);
	};
	/** 
	 * 乘法运算，避免数据相乘小数点后产生多位数和计算精度损失。 
	 * 
	 * @param num1被乘数 | num2乘数 
	 */
	function numMulti(num1, num2) {
		var baseNum = 0;
		try {
			baseNum += num1.toString().split(".")[1].length;
		} catch (e) {}
		try {
			baseNum += num2.toString().split(".")[1].length;
		} catch (e) {}
		return Number(num1.toString().replace(".", "")) * Number(num2.toString().replace(".", "")) / Math.pow(10, baseNum);
	};
	/** 
	 * 除法运算，避免数据相除小数点后产生多位数和计算精度损失。 
	 * 
	 * @param num1被除数 | num2除数 
	 */
	function numDiv(num1, num2) {
		var baseNum1 = 0,
			baseNum2 = 0;
		var baseNum3, baseNum4;
		try {
			baseNum1 = num1.toString().split(".")[1].length;
		} catch (e) {
			baseNum1 = 0;
		}
		try {
			baseNum2 = num2.toString().split(".")[1].length;
		} catch (e) {
			baseNum2 = 0;
		}
		with(Math) {
			baseNum3 = Number(num1.toString().replace(".", ""));
			baseNum4 = Number(num2.toString().replace(".", ""));
			return (baseNum3 / baseNum4) * pow(10, baseNum2 - baseNum1);
		}
	};
function cal(){
	var x=document.getElementById("sum1").value;
	var y=document.getElementById("sum2").value;
	var ch=document.getElementById("op").value;
	var r
	if(!x.trim()||!y.trim()){   //去除空格以及不能为空
		alert('不能为空，请输入数字');
		return;
	}
	x=parseFloat(x);  //将x变成浮点型，以便可以输入小数
	y=parseFloat(y);  //将y变成浮点型，以便可以输入小数
	
	if(isNaN(x)||isNaN(y)){
		alert('请输入数字');
		return;
	}
		
	if(ch=='除'&&y==0){    //判定除数是否为0
		alert('除数不能为0,请输入大于0的数字');
		return;
	}
	
	//解决加法精度问题
//	Math.formatFloat = function(f, digit) { 
//	    var m = Math.pow(10, digit); 
//	    return parseInt(f * m, 10) / m; 
//  } 
   
//	if(ch=='加'){
//		r=Math.formatFloat(x+y,1);
//	}else if(ch=='减'){
//		r=Math.formatFloat(x-y,1);
//	}else if(ch=='乘'){
//		r=Math.formatFloat(x*y,1);
//	}else if(ch=='除'){
//		r=Math.formatFloat(x/y,1);
//	}


	//进行四种运算
	if(ch=='加'){
		r=numAdd(x,y);
	}else if(ch=='减'){
		r=numSub(x,y);
	}else if(ch=='乘'){
		r=numMulti(x,y);
	}else if(ch=='除'){
		r=numDiv(x,y);
	}
	document.getElementById("result").innerText=r;
}